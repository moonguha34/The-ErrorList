# Disaster Management System
# Team
1. Siddhant Bhadoria
1. Avantika Saxena
1. Yash Gupta
1. Moon Guha
1. Aikanshi Jain
